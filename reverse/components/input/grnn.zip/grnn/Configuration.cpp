/*  Configuration.cpp

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#include "Configuration.h"
#include "libreverse/errors/Internal_Exception.h"
#include "Training_Data.h"
#include <sstream>
#include <boost/format.hpp>

#include "libreverse/Reverse.h"
#include "libreverse/Trace.h"

using namespace libreverse::api;
using namespace libreverse::trace;

namespace libreverse
{
  namespace classifier
  {
    template <typename Data_Type>
    Configuration<Data_Type>::Configuration ( bool default_value )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Configuration constructor" );

      for ( boost::uint32_t i = 0;
	    i < Data_Type::ATTRIBUTE_COUNT;
	    ++i )
        {

	  m_attributes[i] = default_value;
        }

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Configuration constructor" );
    }

    template <typename Data_Type>
    Configuration<Data_Type>::Configuration ( const Configuration& rhs )
      : boost::enable_shared_from_this< Configuration<Data_Type> > ( rhs ),
	m_attributes ( rhs.m_attributes )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Configuration copy constructor" );
    }

    template <typename Data_Type>
    void
    Configuration<Data_Type>::set_Attribute ( boost::uint32_t index, bool value )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Configuration::set_Attribute" );

      if ( index > m_attributes.size() )
        {
	  throw errors::Internal_Exception ( errors::Internal_Exception::INVALID_INDEX );
        }

      m_attributes[index] = value;

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Configuration::set_Attribute" );
    }

    template <typename Data_Type>
    bool
    Configuration<Data_Type>::get_Attribute ( boost::uint32_t index )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Configuration::get_Attribute" );

      if ( index > m_attributes.size() )
        {
	  throw errors::Internal_Exception ( errors::Internal_Exception::INVALID_INDEX );
        }

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Configuration::set_Attribute" );

      return m_attributes[index];
    }

    // TODO: If the configuration is to be generic we need to place the
    // string name for attributes into the solution specific file
    // (e.g. class string names into the java file)
    template <typename Data_Type>
    std::string
    Configuration<Data_Type>::to_String ( void )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Configuration::to_String" );

      std::stringstream output;
      output << "---- Configuration ----" << std::endl;
      output << "    ";
      output << Training_Data<Data_Type>::get_Attribute_String_List ( this->shared_from_this() );

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Configuration::to_String" );

      return output.str();
    }

    template <typename Data_Type>
    std::string
    Configuration<Data_Type>::bool_String ( bool value )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Configuration::bool_String" );

      std::string result = "";

      if ( value )
        {
	  result = "true";
        }
      else
        {
	  result = "false";
        }

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Configuration::bool_String" );

      return result;
    }
  } /* namespace classifier */
} /* namespace libreverse */
