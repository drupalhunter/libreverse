/*  Training_Data.cpp

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

//
// C++ Implementation: Training_Data
//
// Description:
//
//
// Author: Stephen Torri, Winard Britt <storri@dell>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "Training_Data.h"
#include "Configuration.h"
#include <sstream>
#include <iostream>
#include <boost/format.hpp>

#include "libreverse/Create.h"
#include "libreverse/Reverse.h"
#include "libreverse/Trace.h"
#include "libreverse/errors/Internal_Exception.h"

using namespace libreverse::alloc;
using namespace libreverse::api;
using namespace libreverse::trace;

namespace libreverse {

  namespace classifier
  {
    template <typename Data_Type>
    Training_Data<Data_Type>::Training_Data ()
      : m_data ( Create::shared_pointer<Data_Type>() )
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data constructor" );
    }

    template <typename Data_Type>
    Training_Data<Data_Type>::~Training_Data ()
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data destructor" );
    }

    template <typename Data_Type>
    classifier_types::Variable_Map::map_type
    Training_Data<Data_Type>::get_Candidate_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config ) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Entering Training_Data::get_Candidate_Data" );

      classifier_types::Variable_Map::map_type output;

      for ( boost::uint32_t index = 0;
	    index < Data_Type::ATTRIBUTE_COUNT;
	    ++index )
	{
	  if ( config->get_Attribute ( index ) )
	    {
	      output[index] = m_data->get_Attribute ( index );
	    }
	}

      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Exiting Training_Data::get_Candidate_Data" );

      return output;
    }

    template <typename Data_Type>
    classifier_types::Variable_Map::map_type::const_iterator
    Training_Data<Data_Type>::begin ( void ) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data::begin (const)" );

      return m_data->begin();
    }

    template <typename Data_Type>
    classifier_types::Variable_Map::map_type::iterator
    Training_Data<Data_Type>::begin ( void )
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data::begin" );

      return m_data->begin();
    }

    template <typename Data_Type>
    classifier_types::Variable_Map::map_type::const_iterator
    Training_Data<Data_Type>::end ( void ) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data::end (const)" );

      return m_data->end();
    }

    template <typename Data_Type>
    classifier_types::Variable_Map::map_type::iterator
    Training_Data<Data_Type>::end ( void )
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Inside Training_Data::end" );

      return m_data->end();
    }

    template <typename Data_Type>
    std::string
    Training_Data<Data_Type>::get_Attribute_String_List ( typename classifier_types::Configuration<Data_Type>::ptr_t config )
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Entering Training_Data::get_Attribute_String_List" );

      std::stringstream output;

      output << Data_Type::get_Attribute_String_List ( config );

      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Exiting Training_Data::get_Attribute_String_List" );

      return output.str();
    }

    template <typename Data_Type>
    std::string
    Training_Data<Data_Type>::to_String ( typename classifier_types::Configuration<Data_Type>::ptr_t config ) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Entering Training_Data::to_String" );

      std::stringstream output;

      output << "---- Training_Data ----" << std::endl;

      output << m_data->to_String ( config );

      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Exiting Training_Data::to_String" );

      return output.str();
    }

    template <typename Data_Type>
    std::string
    Training_Data<Data_Type>::to_XML ( typename classifier_types::Configuration<Data_Type>::ptr_t config ) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Entering Training_Data::to_XML" );

      std::stringstream output;

      output << m_data->to_XML ( config );

      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Exiting Training_Data::to_XML" );

      return output.str();
    }

    template <typename Data_Type>
    bool
    Training_Data<Data_Type>::is_Valid (void) const
    {
      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Entering Training_Data::is_Valid" );

      bool valid = true;

      boost::uint32_t index = 0;

      for ( classifier_types::Variable_Map::map_type::const_iterator cpos = ++(m_data->begin());
	    cpos != m_data->end();
	    ++cpos )
	{
	  if ( ! ( (*cpos).second >= 0.0 && (*cpos).second <= 1.0 ) )
	    {
	      Trace::write_Trace ( TraceArea::CLASSIFIER,
				   TraceLevel::ERROR,
				   boost::str ( boost::format ( "Item #%1$d is not valid" )
						% index ) );
	      valid = false;
	      break;
	    }
          
	  ++index;
	}

      Trace::write_Trace ( TraceArea::CLASSIFIER,
			   TraceLevel::DETAIL,
			   "Exiting Training_Data::is_Valid" );  
       
      return valid;
    }

    template <typename Data_Type>
    void
    Training_Data<Data_Type>::set_Attribute ( boost::uint32_t index, double value )
    {
      if ( index < Data_Type::ATTRIBUTE_COUNT )
	{
	  m_data->set_Attribute(index, value);
	}
      else
	{
	  throw errors::Internal_Exception ( errors::Internal_Exception::INVALID_VALUE );
	}
    }
  } /* namespace classifier */
} /* namespace libreverse */
