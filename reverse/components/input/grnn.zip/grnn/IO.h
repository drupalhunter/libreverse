/*  IO.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

//
// C++ Interface: IO
//
// Description: 
//
//
// Author: Stephen Torri, Winard Britt <storri@dell>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef IO_H
#define IO_H

#include <list>
#include "Classifier_Types.h"
#include <string>

namespace libreverse {

namespace classifier {

  template <typename Data_Type, typename Parser_Type>
  class IO {
  public:

    // TODO: If we are going to put the sigma into the training data file then we will have to either put the
    //       sigma field from the Candidate Solution OR return a Candidate Solution
    //
    // Input: file name of the training data
    static typename classifier_types::Training_Set<Data_Type>::ptr_t get_Data ( std::list<std::string> const& filenames );

    static typename classifier_types::Training_Set<Data_Type>::ptr_t get_Data ( std::string training_data_file );
          
    static void normalize ( typename classifier_types::Training_Set<Data_Type>::Data_List_t& input_set,
			    std::vector<double>& max_list );

  };
} /* namespace classifier */
} /* namespace libreverse */

#include "IO.cpp"

#endif /* IO_H */
