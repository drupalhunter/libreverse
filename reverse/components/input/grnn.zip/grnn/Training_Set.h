/*  Training_Set.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#ifndef TRAINING_SET_H
#define TRAINING_SET_H

#include "Training_Data.h"

namespace libreverse
{
  namespace classifier
  {
    template <typename Data_Type>
    class Training_Set
    {
    public:

      void append ( typename classifier_types::Training_Set<Data_Type>::ptr_t data );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t
      get_Training_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t
      get_Test_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t
      get_Verification_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config );

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator data_Begin() const
      {
	return m_data.begin();
      }

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator data_End() const
      {
	return m_data.end();
      }

      inline void data_Push_Back ( typename classifier_types::Training_Data<Data_Type>::ptr_t data_ptr )
      {
	return m_data.push_back ( data_ptr );
      }

      inline void data_Insert ( typename classifier_types::Training_Set<Data_Type>::Data_List_t& source_data )
      {
	return m_data.insert ( m_data.end(), source_data.begin(), source_data.end() );
      }

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator test_Begin() const
      {
	return m_test.begin();
      }

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator test_End() const
      {
	return m_test.end();
      }
      
      inline void test_Push_Back ( typename classifier_types::Training_Data<Data_Type>::ptr_t data_ptr )
      {
	return m_test.push_back ( data_ptr );
      }

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator verification_Begin() const
      {
	return m_verification.begin();
      }

      inline typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator verification_End() const
      {
	return m_verification.end();
      }

      inline void verification_Push_Back ( typename classifier_types::Training_Data<Data_Type>::ptr_t data_ptr )
      {
	return m_verification.push_back ( data_ptr );
      }

      std::string to_String ( typename classifier_types::Configuration<Data_Type>::ptr_t config =
			      typename classifier_types::Configuration<Data_Type>::ptr_t ( new Configuration<Data_Type>() ) ) const;

      bool is_Valid ( void ) const;

      void set_Attribute_Maximum ( boost::uint32_t key, double value );

      double get_Attribute_Maximum ( boost::uint32_t key ) const;

      std::string get_Attribute_Maximum_XML ( void ) const;

      std::string print_Maximum_Values ( void ) const;

      inline void max_Values_Insert ( classifier_types::Variable_Map::map_type& source_values )
      {
	return m_max_values.insert ( source_values.begin(), source_values.end() );
      }

    private:

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t
      get_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config,
		 typename classifier_types::Training_Set<Data_Type>::Data_List_t& data );
	
      std::string print_Data ( typename classifier_types::Training_Set<Data_Type>::Data_List_t const& data,
			       typename classifier_types::Configuration<Data_Type>::ptr_t config,
			       std::string prefix ) const;

      bool is_Valid_Impl ( typename classifier_types::Training_Set<Data_Type>::Data_List_t const& data,
			   std::string type ) const;

      typename classifier_types::Training_Set<Data_Type>::Data_List_t m_data;
      typename classifier_types::Training_Set<Data_Type>::Data_List_t m_test;
      typename classifier_types::Training_Set<Data_Type>::Data_List_t m_verification;
      classifier_types::Variable_Map::map_type m_max_values;

    };

  } /* namespace classifier */
} /* namespace libreverse */

#include "Training_Set.cpp"

#endif /* TRAINING_SET_H */
