/*  Optimizer.h

    Copyright (C) 2008 Stephen Torri

    This file is part of Libreverse.

    Libreverse is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published
    by the Free Software Foundation; either version 3, or (at your
    option) any later version.

    Libreverse is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see
    <http://www.gnu.org/licenses/>.
*/

#ifndef OPTIMIZER_H
#define OPTIMIZER_H

#include "Classifier_Types.h"
#include "Training_Set.h"

namespace libreverse {
  namespace classifier {

    template <typename Data_Type>
    class Optimizer
    {
    public:

      /*
	\brief Initialize Optimizer
	\pre Training Data objects are initialized
	\post The optimizer is prepared to do work.
      */
      void init ( typename classifier_types::Candidate_Solution<Data_Type>::ptr_t initial_guess,
		  typename classifier_types::Training_Set<Data_Type>::ptr_t data,
		  double mutation_amount = 0.125,
		  boost::uint32_t iteration_limit = 10 );
     
      /* \brief Process the Training Data in order to obtain the best sigma
         \pre The Training Data objects have been received (m_input_data is not empty)
         \post The best sigma has been found the optimizer. Tranining Data is unchanged.
      */
      void process (void);
      
      typename classifier_types::Candidate_Solution<Data_Type>::ptr_t test (void);

    private:

      /* \brief Perform the evolutionary hill climber search
         \param start_sigma The inital guess for sigma
         \param mutation_amount The magnitude of the perturbation applied on each cycle
         \param iterations The number of candidate solutions evaluated
         \return Best sigma found by the search
         \pre The Training Data objects have been received (m_input_data is not empty)
         \post The best sigma has been found the evolutionary hill climber. Tranining Data is unchanged.
      */
      double use_Evolutionary_Hill_Climber ( double start_sigma, double mutation_amount, int iterations );

      /* \brief Perform the logarithmc search
         \param iterations The number of candidate solutions evaluated
         \param lower_bound The lowest value of the search range
         \param upper_bound the largest value of the search range
         \param steps_per_iteration The granularity of the search
         \return Best sigma found by the search
         \pre The Training Data objects have been received (m_input_data is not empty)
         \post The best sigma has been found the logarithmic search. Tranining Data is unchanged.
      */
      double use_Logarithmic ( int iterations, double lower_bound, double upper_bound, int steps_per_iteration );

      void mutate_Attributes ();
      
      void mutate_Sigma ();

      typename classifier_types::Candidate_Solution<Data_Type>::ptr_t m_potential_solution;
      
      typename classifier_types::Candidate_Solution<Data_Type>::ptr_t m_best_solution;

      typename classifier_types::Training_Set<Data_Type>::ptr_t m_data;
      
      double m_mutation_amount;
      
      boost::uint32_t m_iteration_limit;
    };

  } /* namespace classifier */
} /* namespace libreverse */

#include "Optimizer.cpp"

#endif /* OPTIMIZER_H */
