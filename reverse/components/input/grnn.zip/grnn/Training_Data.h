/*  Training_Data.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#ifndef TRAINING_DATA_H
#define TRAINING_DATA_H

#include <boost/shared_ptr.hpp>
#include <boost/cstdint.hpp>
#include <string>
#include <map>
#include "Classifier_Types.h"

namespace libreverse {

  namespace classifier
  {
    template <typename Data_Type>
    class Training_Data
    {
    public:

      Training_Data ();

      ~Training_Data();

      typename classifier_types::Variable_Map::map_type
      get_Candidate_Data ( typename classifier_types::Configuration<Data_Type>::ptr_t config ) const;

      //std::string to_String ( boost::uint32_t index ) const;

      static std::string get_Attribute_String_List
	( typename classifier_types::Configuration<Data_Type>::ptr_t config =
	  typename classifier_types::Configuration<Data_Type>::ptr_t ( new Configuration<Data_Type>() ) );

      std::string to_String
	( typename classifier_types::Configuration<Data_Type>::ptr_t config =
	  typename classifier_types::Configuration<Data_Type>::ptr_t ( new Configuration<Data_Type>() ) ) const;
      
      std::string to_XML
	( typename classifier_types::Configuration<Data_Type>::ptr_t config =
	  typename classifier_types::Configuration<Data_Type>::ptr_t ( new Configuration<Data_Type>() ) ) const;

      classifier_types::Variable_Map::map_type::const_iterator begin ( void ) const;
      classifier_types::Variable_Map::map_type::iterator begin ( void );

      classifier_types::Variable_Map::map_type::const_iterator end ( void ) const;
      classifier_types::Variable_Map::map_type::iterator end ( void );

      bool is_Valid (void) const;

      void set_Attribute ( boost::uint32_t index, double value );

    private:

      boost::shared_ptr<Data_Type> m_data;
    };

  } /* namespace classifier */

} /* namespace libreverse */

#include "Training_Data.cpp"

#endif /* TRAINING_DATA_H */
