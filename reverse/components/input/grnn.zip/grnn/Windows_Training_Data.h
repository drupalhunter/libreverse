
/*  Windows_Training_Data.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#ifndef WINDOWS_TRAINING_DATA_H
#define WINDOWS_TRAINING_DATA_H

#include <boost/shared_ptr.hpp>
#include <boost/cstdint.hpp>
#include <string>
#include "Classifier_Types.h"

namespace libreverse
{
  namespace classifier
  {
    class Windows_Training_Data
    {
    public:

      static const boost::uint8_t ATTRIBUTE_COUNT;
      static const boost::uint8_t CLASSIFIER_TARGET;

      enum Attributes
        {
	  ATTRIBUTE_COMPILER_ID = 0,
	  ATTRIBUTE_FILESIZE = 1,
	  ATTRIBUTE_DOS_MAGIC_NUMBER = 2,
	  ATTRIBUTE_EXE_HEADER_ADDRESS = 3,
	  ATTRIBUTE_PE_MAGIC_NUMBER = 4,
	  ATTRIBUTE_COFF_MACHINE = 5,
	  ATTRIBUTE_COFF_TIMESTAMP = 6,
	  ATTRIBUTE_COFF_NUMBER_OF_SYMBOLS = 7,
	  ATTRIBUTE_PE_OPT_MAGIC_VALUE = 8,
	  ATTRIBUTE_PE_OPT_LINKER_VERSION = 9,
	  ATTRIBUTE_PE_OPT_CODE_SIZE = 10,
	  ATTRIBUTE_PE_OPT_INIT_DATA_SIZE = 11,
	  ATTRIBUTE_PE_OPT_UNINIT_DATA_SIZE = 12,
	  ATTRIBUTE_PE_OPT_ENTRY_POINT = 13,
	  ATTRIBUTE_PE_OPT_CODE_ADDRESS = 14,
	  ATTRIBUTE_PE_OPT_OPERATING_SYSTEM_VERSION = 15,
	  ATTRIBUTE_PE_OPT_IMAGE_VERSION = 16,
	  ATTRIBUTE_PE_OPT_MAJOR_SUBSYSTEM_VERSION = 17,
	  ATTRIBUTE_PE_OPT_IMAGE_SIZE = 18,
	  ATTRIBUTE_PE_OPT_HEADER_SIZE = 19
        };

      friend class Windows_Training_Data_Parser;

      Windows_Training_Data ();

      ~Windows_Training_Data();

      classifier_types::Variable_Map::map_type
      get_Candidate_Data ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config ) const;

      static std::string get_Attribute_String_List ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config );


      std::string to_String ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config ) const;

      std::string to_XML ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config ) const;

      classifier_types::Variable_Map::map_type::const_iterator begin ( void ) const;
      classifier_types::Variable_Map::map_type::iterator begin ( void );

      classifier_types::Variable_Map::map_type::const_iterator end ( void ) const;
      classifier_types::Variable_Map::map_type::iterator end ( void );

      void set_Attribute ( boost::uint32_t index, double value );

      double get_Attribute ( boost::uint32_t index ) const;

    private:

      classifier_types::Variable_Map::map_type m_data;
    };

  } /* namespace classifier */
} /* namespace libreverse */

#endif /* WINDOWS_TRAINING_DATA_H */
