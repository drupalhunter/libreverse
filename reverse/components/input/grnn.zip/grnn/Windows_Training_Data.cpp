/*  Windows_Training_Data.cpp

    Copyright (C) 2008 Stephen Torri

    This file is part of Libreverse.

    Libreverse is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published
    by the Free Software Foundation; either version 3, or (at your
    option) any later version.

    Libreverse is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see
    <http://www.gnu.org/licenses/>.
*/

//
// C++ Implementation: Training_Data
//
// Description:
//
//
// Author: Stephen Torri, Winard Britt <storri@dell>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "Windows_Training_Data.h"
#include "libreverse/errors/Internal_Exception.h"
#include "Configuration.h"
#include <sstream>
#include <iostream>
#include <boost/format.hpp>

#include "libreverse/Reverse.h"
#include "libreverse/Trace.h"

using namespace libreverse::api;
using namespace libreverse::trace;

namespace libreverse
{
  namespace classifier
  {

    const boost::uint8_t Windows_Training_Data::ATTRIBUTE_COUNT = 20;
    const boost::uint8_t Windows_Training_Data::CLASSIFIER_TARGET = Windows_Training_Data::ATTRIBUTE_COMPILER_ID;

    Windows_Training_Data::Windows_Training_Data ()
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data constructor" );
    }

    Windows_Training_Data::~Windows_Training_Data ()
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data destructor" );
    }

    classifier_types::Variable_Map::map_type
    Windows_Training_Data::get_Candidate_Data ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config ) const
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Windows_Training_Data::get_Candidate_Data" );

      classifier_types::Variable_Map::map_type output;

      for ( boost::uint32_t index = 0;
	    index < Windows_Training_Data::ATTRIBUTE_COUNT;
	    ++index )
        {
	  if ( config->get_Attribute ( index ) )
            {
	      classifier_types::Variable_Map::map_type::const_iterator pos = m_data.find ( index );
	      output[index] = ( *pos ).second;
            }
        }

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Windows_Training_Data::get_Candidate_Data" );

      return output;
    }

    std::string
    Windows_Training_Data::get_Attribute_String_List ( classifier_types::Configuration<Windows_Training_Data>::ptr_t config )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Windows_Training_Data::get_Attribute_String_List" );
      
      std::stringstream output;

      output << boost::format ( "Windows_Training_Data #%1%" ) % index << std::endl;
	
      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_COMPILER_ID ) )
        {
	  output << "Compiler_ID" << std::endl;
        }

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_FILESIZE ) )
        {
	  output << "Filesize" << std::endl;
        }

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_DOS_MAGIC_NUMBER ) )
	{
	  output << "DOS magic number" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_EXE_HEADER_ADDRESS ) )
	{
	  output << "DOS Exe header address" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_MAGIC_NUMBER ) )
	{
	  output << "PE magic number" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_COFF_MACHINE ) )
	{
	  output << "COFF machine" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_COFF_TIMESTAMP ) )
	{
	  output << "COFF timestamp" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_COFF_NUMBER_OF_SYMBOLS ) )
	{
	  output << "COFF number of symbols" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_MAGIC_VALUE ) )
	{
	  output << "Optional Header magic value" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_LINKER_VERSION ) )
	{
	  output << "Optional Header linker version" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_CODE_SIZE ) )
	{
	  output << "Optional Header code size" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_INIT_DATA_SIZE ) )
	{
	  output << "Optional Header initialized data size" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_UNINIT_DATA_SIZE ) )
	{
	  output << "Optional Header uninitialized data size" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_ENTRY_POINT ) )
	{
	  output << "Optional Header entry point" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_CODE_ADDRESS ) )
	{
	  output << "Optional Header code address" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_OPERATING_SYSTEM_VERSION ) )
	{
	  output << "Optional Header operating system version" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_IMAGE_VERSION ) )
	{
	  output << "Optional Header image version" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_MAJOR_SUBSYSTEM_VERSION ) )
	{
	  output << "Optional Header major subsystem version" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_IMAGE_SIZE ) )
	{
	  output << "Optional Header image size" << std::endl;
	}

      if ( config->get_Attribute ( Windows_Training_Data::ATTRIBUTE_PE_OPT_HEADER_SIZE ) )
	{
	  output << "Optional Header header size" << std::endl;
	}

      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Windows_Training_Data::get_Attribute_String_List" );

      return output.str();
    }

    std::string
    Windows_Training_Data::to_String ( classifier_types::Configuration<Windows_Training_Data>::ptr_t ) const
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Windows_Training_Data::to_String" );

      std::stringstream output;

      /*


      output << boost::format ( "Windows_Training_Data #%1%" ) % index << std::endl
	     << boost::format ( "  compiler id................: %1%" ) % this->get_Attribute ( ATTRIBUTE_COMPILER_ID )  << std::endl
	     << boost::format ( "  file size..................: %1% bytes" ) % this->get_Attribute ( ATTRIBUTE_FILESIZE )  << std::endl
	     << boost::format ( "  DOS magic number...........: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_DOS_MAGIC_NUMBER ) << std::endl
	     << boost::format ( "  DOS EXE header address.....: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_EXE_HEADER_ADDRESS ) << std::endl
	     << boost::format ( "  PE magic number............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_MAGIC_NUMBER ) << std::endl
	     << boost::format ( "  COFF machine...............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_COFF_MACHINE ) << std::endl
	     << boost::format ( "  COFF timestamp.............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_COFF_TIMESTAMP ) << std::endl
	     << boost::format ( "  COFF number of symbols.....: %1%" ) % this->get_Attribute ( ATTRIBUTE_COFF_NUMBER_OF_SYMBOLS ) << std::endl
	     << boost::format ( "  Optional Header magic value: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_MAGIC_VALUE ) << std::endl
	     << boost::format ( "  Optional Header linker version: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_LINKER_VERSION ) << std::endl
	     << boost::format ( "  Optional Header code size: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_CODE_SIZE ) << std::endl
	     << boost::format ( "  Optional Header initialized data size: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_INIT_DATA_SIZE ) << std::endl

	     << boost::format ( "  Optional Header uninitialized data size: 0x%1%" )
	% this->get_Attribute ( ATTRIBUTE_PE_OPT_UNINIT_DATA_SIZE ) << std::endl

	     << boost::format ( "  Optional Header entry point: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_ENTRY_POINT ) << std::endl
	     << boost::format ( "  Optional Header code address: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_CODE_ADDRESS ) << std::endl

	     << boost::format ( "  Optional Header operating system version: 0x%1%" )
	% this->get_Attribute ( ATTRIBUTE_PE_OPT_OPERATING_SYSTEM_VERSION ) << std::endl;
      */
	
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Windows_Training_Data::to_String" );

      return output.str();
    }

    std::string
    Windows_Training_Data::to_XML ( classifier_types::Configuration<Windows_Training_Data>::ptr_t ) const
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Entering Windows_Training_Data::to_XML" );

      std::stringstream output;

      /*


      output << boost::format ( "Windows_Training_Data #%1%" ) % index << std::endl
	     << boost::format ( "  compiler id................: %1%" ) % this->get_Attribute ( ATTRIBUTE_COMPILER_ID )  << std::endl
	     << boost::format ( "  file size..................: %1% bytes" ) % this->get_Attribute ( ATTRIBUTE_FILESIZE )  << std::endl
	     << boost::format ( "  DOS magic number...........: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_DOS_MAGIC_NUMBER ) << std::endl
	     << boost::format ( "  DOS EXE header address.....: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_EXE_HEADER_ADDRESS ) << std::endl
	     << boost::format ( "  PE magic number............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_MAGIC_NUMBER ) << std::endl
	     << boost::format ( "  COFF machine...............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_COFF_MACHINE ) << std::endl
	     << boost::format ( "  COFF timestamp.............: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_COFF_TIMESTAMP ) << std::endl
	     << boost::format ( "  COFF number of symbols.....: %1%" ) % this->get_Attribute ( ATTRIBUTE_COFF_NUMBER_OF_SYMBOLS ) << std::endl
	     << boost::format ( "  Optional Header magic value: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_MAGIC_VALUE ) << std::endl
	     << boost::format ( "  Optional Header linker version: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_LINKER_VERSION ) << std::endl
	     << boost::format ( "  Optional Header code size: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_CODE_SIZE ) << std::endl
	     << boost::format ( "  Optional Header initialized data size: 0x%1%" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_INIT_DATA_SIZE ) << std::endl

	     << boost::format ( "  Optional Header uninitialized data size: 0x%1%" )
	% this->get_Attribute ( ATTRIBUTE_PE_OPT_UNINIT_DATA_SIZE ) << std::endl

	     << boost::format ( "  Optional Header entry point: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_ENTRY_POINT ) << std::endl
	     << boost::format ( "  Optional Header code address: 0x%1$X" ) % this->get_Attribute ( ATTRIBUTE_PE_OPT_CODE_ADDRESS ) << std::endl

	     << boost::format ( "  Optional Header operating system version: 0x%1%" )
	% this->get_Attribute ( ATTRIBUTE_PE_OPT_OPERATING_SYSTEM_VERSION ) << std::endl;
      */
	
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Exiting Windows_Training_Data::to_XML" );

      return output.str();
    }

    classifier_types::Variable_Map::map_type::const_iterator
    Windows_Training_Data::begin ( void ) const
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data::begin (const)" );

      return m_data.begin();
    }

    classifier_types::Variable_Map::map_type::iterator
    Windows_Training_Data::begin ( void )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data::begin" );

      return m_data.begin();
    }

    classifier_types::Variable_Map::map_type::const_iterator
    Windows_Training_Data::end ( void ) const
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data::end (const)" );

      return m_data.end();
    }

    classifier_types::Variable_Map::map_type::iterator
    Windows_Training_Data::end ( void )
    {
      Trace::write_Trace ( TraceArea::GRNN_DATA,
			   TraceLevel::DETAIL,
			   "Inside Windows_Training_Data::end" );

      return m_data.end();
    }

    void
    Windows_Training_Data::set_Attribute ( boost::uint32_t index, double value )
    {
      if ( index < Windows_Training_Data::ATTRIBUTE_COUNT )
	{
          m_data[index] = value;
	}
    }

    double
    Windows_Training_Data::get_Attribute ( boost::uint32_t index ) const
    {
      if ( index < Windows_Training_Data::ATTRIBUTE_COUNT )
	{
	  classifier_types::Variable_Map::map_type::const_iterator cpos = m_data.find ( index );
	  if ( cpos == m_data.end() )
	    {
	      throw errors::Internal_Exception ( errors::Internal_Exception::INVALID_INDEX );
	    }
	  else
	    {
	      return (*cpos).second;
	    }
	}
      else
	{
	  throw errors::Internal_Exception ( errors::Internal_Exception::INVALID_INDEX );
	}
    }
  } /* namespace classifier */
} /* namespace libreverse */
