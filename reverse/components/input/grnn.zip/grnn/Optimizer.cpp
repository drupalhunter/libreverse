
/*  Optimizer.cpp

    Copyright (C) 2008 Stephen Torri

    This file is part of Libreverse.

    Libreverse is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published
    by the Free Software Foundation; either version 3, or (at your
    option) any later version.

    Libreverse is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see
    <http://www.gnu.org/licenses/>.
*/

#include "Optimizer.h"

#include "libreverse/Create.h"
#include "libreverse/Trace.h"

#include <iostream>
#include <boost/format.hpp>

using namespace libreverse::alloc;

namespace libreverse
{
  namespace classifier
  {
  
    template <typename Data_Type>
    void
    Optimizer<Data_Type>::init ( typename classifier_types::Candidate_Solution<Data_Type>::ptr_t initial_guess,
				 typename classifier_types::Training_Set<Data_Type>::ptr_t data,
				 double mutation_amount,
				 boost::uint32_t iteration_limit )
    {
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Entering Optimizer::init" );

      m_potential_solution = initial_guess;
      m_best_solution = Create::shared_pointer < Candidate_Solution<Data_Type> >();
      m_data = data;
      m_mutation_amount = mutation_amount;
      m_iteration_limit = iteration_limit;

      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Exiting Optimizer::init" );
    }

    template <typename Data_Type>
    void
    Optimizer<Data_Type>::process ()
    {
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Entering Optimizer::process" );

      for ( boost::uint32_t i = 0;
	    i < m_iteration_limit;
	    ++i )
        {
	 Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
	 TraceLevel::DATA,
	 boost::str ( boost::format ("Iteration #%1%" ) % i ) );
 
	  m_potential_solution->evaluate ( m_data );

	  //this->mutate_Attributes ();

	  for ( boost::uint32_t j = 0;
		j < 10;
		++j )
            {
	 Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
	 TraceLevel::DATA,
	 boost::str ( boost::format ("  Sub-iteration #%1%:%2%" ) % i % j ) );

	      this->mutate_Sigma ();

	      m_potential_solution->evaluate ( m_data );

		 Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
		 TraceLevel::DATA,
		 boost::str ( boost::format ("Present solution (%1$1.10f) --- best solution (%2$1.10f)" )
		 % m_potential_solution->get_Fitness()
		 % m_best_solution->get_Fitness() ) );

	      if ( m_potential_solution->get_Fitness() > m_best_solution->get_Fitness() )
		{                 
		     Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
		     TraceLevel::DATA,
		     "Saving potential solution as best solution" );
                  
		     Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
		     TraceLevel::DATA,
		     m_potential_solution->to_String() );
                  
		     Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
		     TraceLevel::DATA,
		     m_best_solution->to_String() );

                  // Deep copy m_potential_solution into m_best_solution
                  m_best_solution = Create::shared_pointer < Candidate_Solution<Data_Type> > ( *m_potential_solution );

                  Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
                                       TraceLevel::DATA,
				       boost::str ( boost::format ( "Best solution Sigma: %1$1.10f" ) % m_best_solution->get_Sigma() ) );

                  Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
                                       TraceLevel::DATA,
				       boost::str ( boost::format ( "Best solution Fitness: %1$1.10f" ) % m_best_solution->get_Fitness() ) );

                  Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
                                       TraceLevel::DATA,
				       boost::str ( boost::format ( "Best solution Mean Distance Squared: %1$1.10f" )
						    % m_best_solution->get_Mean_Distance_Squared() ) );                  

		  // print current iteration number
		  Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
				       TraceLevel::DATA,
				       boost::str ( boost::format ( "Number of iterations for best solution: %1%" )
						    % ( i + 1 ) ) );

		  m_best_solution->set_Iteration_Count ( i + 1 );
		}

	      if ( m_best_solution->get_Fitness() == 1.0 )
		{
		  i = m_iteration_limit;
		  break;
		}
            }
        }

      // TEST: REMOVE ME LATER
      std::cout << "------- PROCESS RESULT ----------" << std::endl;
      std::cout << m_best_solution->to_String() << std::endl;

      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Exiting Optimizer::process" );
    }

    template <typename Data_Type>
    typename classifier_types::Candidate_Solution<Data_Type>::ptr_t
    Optimizer<Data_Type>::test ()
    {
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Entering Optimizer::test" );

      m_best_solution->test ( m_data );
       
      // TEST: REMOVE ME LATER
      std::cout << "------- TEST RESULT ----------" << std::endl;
      std::cout << m_best_solution->to_String() << std::endl;

      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Exiting Optimizer::test" );

      return m_best_solution;
    }

    template <typename Data_Type>    
    void
    Optimizer<Data_Type>::mutate_Attributes ( )
    {
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Entering Optimizer::mutate_Attributes" );

      // Pick a random attribute and flip it
      boost::uint32_t attribute_index = rand() % Data_Type::ATTRIBUTE_COUNT;
      typename classifier_types::Configuration<Data_Type>::ptr_t config_ptr = m_potential_solution->get_Config();
      bool flag = config_ptr->get_Attribute ( attribute_index );
      config_ptr->set_Attribute ( attribute_index, !flag );
        
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Exiting Optimizer::mutate_Attributes" );
    }

    template <typename Data_Type>
    void
    Optimizer<Data_Type>::mutate_Sigma ()
    {
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Entering Optimizer::mutate_Sigma" );

      double random_number = ( 2 * static_cast<double>(rand()) / static_cast<double>(RAND_MAX) ) - 1;
      float old_sigma = m_potential_solution->get_Sigma();
      m_potential_solution->set_Sigma ( old_sigma + random_number * m_mutation_amount * old_sigma );
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Old sigma: %1$1.10d" ) % old_sigma ) );
       
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Random Number: %1$1.10d" ) % random_number ) );
       
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Mutation amount: %1$1.10d" ) % m_mutation_amount ) );
       
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "New sigma: %1$1.10d" ) % ( old_sigma + random_number * m_mutation_amount * old_sigma ) ) );
       
      Trace::write_Trace ( TraceArea::GRNN_OPTIMIZER,
			   TraceLevel::DETAIL,
			   "Exiting Optimizer::mutate_Sigma" );
    }
  } /* namespace classifier */
} /* namespace libreverse */
