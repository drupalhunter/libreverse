/*  Selection_Policy.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

//
// C++ Interface: Selection Policy
//
// Description:
//
//
// Author: Stephen Torri, Winard Britt <storri@dell>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#ifndef SELECTION_POLICY_H
#define SELECTION_POLICY_H

#include <list>
#include "Classifier_Types.h"
#include <string>

namespace libreverse
{
  namespace classifier
  {

    template <typename Data_Type>
      class Selection_Policy
      {
      public:
	static typename classifier_types::Training_Set<Data_Type>::ptr_t
	execute ( typename classifier_types::Training_Set<Data_Type>::Data_List_t const& input_data );
      };
  } /* namespace classifier */
} /* namespace libreverse */

#include "Selection_Policy.cpp"

#endif /* SELECTION_POLICY_H */
