/*  Candidate_Solution.cpp

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

//
// C++ Implementation: Candidate_Solution
//
// Description:
//
//
// Author: Stephen Torri, Winard Britt <storri@dell>, (C) 2007
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "Candidate_Solution.h"
#include "GRNN.h"

#include "libreverse/Trace.h"
#include "libreverse/Create.h"

#include <boost/format.hpp>
#include <sstream>

using namespace libreverse::alloc;

namespace libreverse
{

  namespace classifier
  {

    template <typename Data_Type>
    Candidate_Solution<Data_Type>::Candidate_Solution ( double sigma,
							double fitness,
							typename classifier_types::Configuration<Data_Type>::ptr_t config )
      : m_sigma ( sigma ),
	m_fitness ( fitness ),
	m_mean_distance_squared ( 0.0 ),
	m_iteration_count ( 0 ),
	m_config ( config )
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution constructor" );

      // Check at least one attribute is flagged in the Configuration
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "sigma: %1%" ) % sigma ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "fitness: %1%" ) % fitness ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Configuration: %1%" ) % config->to_String() ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Exiting Candidate_Solution constructor" );
    }

    template <typename Data_Type>
    Candidate_Solution<Data_Type>::Candidate_Solution ( const Candidate_Solution& rhs )
      : m_sigma ( rhs.m_sigma ),
	m_fitness ( rhs.m_fitness ),
	m_mean_distance_squared ( rhs.m_mean_distance_squared ),
	m_iteration_count ( rhs.m_iteration_count ),
	m_config ( Create::shared_pointer< Configuration<Data_Type> >( *rhs.m_config ) )
    {}

    template <typename Data_Type>
    void
    Candidate_Solution<Data_Type>::evaluate ( typename classifier_types::Training_Set<Data_Type>::ptr_t data )
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::evaluate" );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t data_map = data->get_Training_Data ( m_config );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t verification_map = data->get_Verification_Data ( m_config );

      GRNN<Data_Type> g_ref ( m_sigma, data_map, verification_map );
      m_fitness = g_ref.execute();
      m_mean_distance_squared = g_ref.get_Mean_Distance_Squared();

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Guess Sigma: %1$1.10f" ) % m_sigma ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Guess Fitness: %1$1.10f" ) % m_fitness ) );


      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::evaluate" );
    }

    template <typename Data_Type>
    void Candidate_Solution<Data_Type>::test ( typename classifier_types::Training_Set<Data_Type>::ptr_t data )
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::test" );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t data_map = data->get_Training_Data ( m_config );
      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t test_map = data->get_Test_Data ( m_config );

      GRNN<Data_Type> g_ref ( m_sigma, data_map, test_map );
      m_fitness = g_ref.execute();
      m_mean_distance_squared = g_ref.get_Mean_Distance_Squared();
      m_iteration_count = 0;

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Final Sigma: %1$1.10f" ) % m_sigma ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Final Fitness: %1$1.10d" ) % m_fitness ) );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::test" );
    }

    template <typename Data_Type>
    void Candidate_Solution<Data_Type>::set_Sigma ( double new_sigma )
    {
       
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::set_Sigma" );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "New Sigma = %1%" ) % new_sigma ) );

      m_sigma = new_sigma;

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Exiting Candidate_Solution<Data_Type>::set_Sigma" );
    }

    template <typename Data_Type>
    double
    Candidate_Solution<Data_Type>::get_Fitness ( void ) const
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Inside Candidate_Solution<Data_Type>::get_Fitness" );

      return m_fitness;
    }

    template <typename Data_Type>
    double
    Candidate_Solution<Data_Type>::get_Sigma ( void ) const
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Inside Candidate_Solution<Data_Type>::get_Sigma" );

      return m_sigma;
    }

    template <typename Data_Type>
    typename classifier_types::Configuration<Data_Type>::ptr_t
    Candidate_Solution<Data_Type>::get_Config ( void )
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Inside Candidate_Solution<Data_Type>::get_Config" );

      return m_config;
    }

    template <typename Data_Type>    
    std::string
    Candidate_Solution<Data_Type>::to_String ( void )
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::to_String" );

      std::stringstream output;
       
      output << "---------------------------------------" << std::endl
	     << "--------- Candidate Solution ----------" << std::endl
	     << "---------------------------------------" << std::endl
	     << boost::format("  Sigma.....%1$1.10f") % m_sigma << std::endl
	     << boost::format("  Fitness:..%1$1.10f") % m_fitness << std::endl
	     << boost::format("  Mean Distance Squared:..%1$1.10f") % m_mean_distance_squared << std::endl
	     << boost::format("  Iteration Count:..%1$1.10f") % m_iteration_count << std::endl
	     << m_config->to_String() << std::endl;
       
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Exiting Candidate_Solution<Data_Type>::to_String" );

      return output.str();
    }

    template <typename Data_Type>
    void Candidate_Solution<Data_Type>::set_Iteration_Count ( boost::uint32_t count )
    {
       
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Entering Candidate_Solution<Data_Type>::set_Iteration_Count" );

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "New Iteration Count = %1%" ) % count ) );

      m_iteration_count = count;

      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Exiting Candidate_Solution<Data_Type>::set_Iteration_Count" );
    }

    template <typename Data_Type>
    double Candidate_Solution<Data_Type>::get_Mean_Distance_Squared ( void ) const
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Inside Candidate_Solution<Data_Type>::get_Mean_Distance_Squared" );

      return m_mean_distance_squared;
    }

    template <typename Data_Type>
    boost::uint32_t
    Candidate_Solution<Data_Type>::get_Iteration_Count ( void ) const
    {
      Trace::write_Trace ( TraceArea::CANDIDATE_SOLUTION,
			   TraceLevel::DETAIL,
			   "Inside Candidate_Solution<Data_Type>::get_Iteration_Count" );

      return m_iteration_count;
    }

  } /* namespace classifier */
} /* namespace libreverse */
