/*  IO.cpp

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#include "IO.h"
#include "Selection_Policy.h"
#include "Training_Data.h"

#include <iostream>
#include <boost/format.hpp>
#include <boost/filesystem.hpp>

#include "libreverse/Trace.h"
#include "libreverse/errors/IO_Exception.h"

using namespace libreverse::api;
using namespace libreverse::trace;

namespace libreverse {

  namespace classifier {

    template <typename Data_Type, typename Parser_Type>
    typename classifier_types::Training_Set<Data_Type>::ptr_t
    IO<Data_Type,Parser_Type>::get_Data ( std::list<std::string> const& filenames )
    {
      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DETAIL,
                           "Entering IO::get_Data" );

      Parser_Type parser;

      typename classifier_types::Training_Set<Data_Type>::Data_List_t output_data;

      // For each XML file we want to
      for ( std::list<std::string>::const_iterator cpos = filenames.begin();
            cpos != filenames.end();
            ++cpos )
	{
	  // If file does not exist throw exception
	  if ( ! boost::filesystem::exists ( *cpos ) )
	    {
	      Trace::write_Trace ( TraceArea::IO,
				   TraceLevel::ERROR,
				   boost::str ( boost::format ( "Cannot find %s%" ) % *cpos ) );

	      throw errors::IO_Exception ( errors::IO_Exception::INVALID_FILE_NAME );
	    }

	  // - parse input
	  typename classifier_types::Training_Set<Data_Type>::Data_List_t input_data = parser.get_Data ( *cpos );
         
	  Trace::write_Trace ( TraceArea::IO,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "Size of input: %1%" ) % input_data.size() ) );
         
	  output_data.insert ( output_data.end(), input_data.begin(), input_data.end() );
	}
      // End loop

#ifdef LIBREVERSE_DEBUG
      //boost::uint32_t count = 0;
         
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "  Dump BEFORE normalizing" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
         
      for ( typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator data_pos = output_data.begin();
            data_pos != output_data.end();
            ++data_pos )
	{
	  //Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, (*data_pos)->to_String(count) );
	  //++count;
	  Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, (*data_pos)->to_String() );
	}
#endif /* LIBREVERSE_DEBUG */
         
      // - normalize input data
      std::vector<double> max_list ( Data_Type::ATTRIBUTE_COUNT, 0.0 );

      normalize ( output_data, max_list );

#ifdef LIBREVERSE_DEBUG
      //count = 0;
         
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "  Dump AFTER normalizing" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
         
      for ( typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator data_pos = output_data.begin();
            data_pos != output_data.end();
            ++data_pos )
	{
	  //Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, (*data_pos)->to_String(count) );
	  //++count;
	  Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, (*data_pos)->to_String() );
	}
#endif /* LIBREVERSE_DEBUG */

      // - apply Selection Policy
      typename classifier_types::Training_Set<Data_Type>::ptr_t output_set = Selection_Policy<Data_Type>::execute ( output_data );

      // Save maximum values
      for ( std::vector<double>::const_iterator cpos = max_list.begin();
	    cpos != max_list.end();
	    ++cpos )
	{
	  boost::uint32_t key = ( cpos - max_list.begin() );
	  output_set->set_Attribute_Maximum ( key, (*cpos) );
	}
      
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "  Dump AFTER selection policy" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, "****************************" );
      Trace::write_Trace ( TraceArea::IO, TraceLevel::DATA, output_set->to_String() );

      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DETAIL,
                           "Exiting IO::get_Data" );

      // Return results
      return output_set;
    }

    template <typename Data_Type, typename Parser_Type>
    typename classifier_types::Training_Set<Data_Type>::ptr_t
    IO<Data_Type,Parser_Type>::get_Data ( std::string training_data_file )
    {
      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DETAIL,
                           "Entering IO::get_Data" );

      // If file does not exist throw exception
      if ( ! boost::filesystem::exists ( training_data_file ) )
	{
	  Trace::write_Trace ( TraceArea::IO,
			       TraceLevel::ERROR,
			       boost::str ( boost::format ( "Cannot find %s%" ) % training_data_file ) );
	  
	  throw errors::IO_Exception ( errors::IO_Exception::INVALID_FILE_NAME );
	}

      Parser_Type parser;

      typename classifier_types::Training_Set<Data_Type>::Data_List_t input_data = parser.get_Data ( training_data_file );

#ifdef LIBREVERSE_DEBUG
      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DATA,
			   "Dumping input data" );

      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DATA,
			   boost::str ( boost::format ( "Input data size: %1%" ) % input_data.size() ) );

      for ( typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator cpos = input_data.begin();
	    cpos != input_data.end();
	    ++cpos )
	{
	  Trace::write_Trace ( TraceArea::IO,
			       TraceLevel::DATA,
			       (*cpos)->to_String() );
	}

#endif /* LIBREVERSE_DEBUG */

      typename classifier_types::Training_Set<Data_Type>::ptr_t output_set ( new classifier::Training_Set<Data_Type>() );
      output_set->data_Insert ( input_data );
      output_set->max_Values_Insert ( parser.get_Max_Values() );
      return output_set;
    }

    template <typename Data_Type, typename Parser_Type>
    void
    IO<Data_Type,Parser_Type>::normalize ( typename classifier_types::Training_Set<Data_Type>::Data_List_t& input_set,
					   std::vector<double>& max_list )
    {
      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DETAIL,
                           "Exiting IO::normalize" );

      for ( typename classifier_types::Training_Set<Data_Type>::Data_List_t::const_iterator set_pos = input_set.begin();
            set_pos != input_set.end();
            ++set_pos )
	{
	  // We skip the first entry in the training data since it is the compiler id (desired output)
	  typename classifier_types::Training_Data<Data_Type>::Variable_List_t::const_iterator data_pos = (*set_pos)->begin();
	  ++data_pos;

	  for ( ;
		data_pos != (*set_pos)->end();
		++data_pos )
	    {
	      Trace::write_Trace ( TraceArea::IO,
				   TraceLevel::DATA,
				   boost::str ( boost::format( "Pos (%1$d) => Value (%2$f)" )
						% (*data_pos).first
						% (*data_pos).second ) );

	      // If the input_set value (pos.second) at the present position is greater than
	      // the preivously stored maximum value for this variable (max_list[pos.first])
	      // then save the greater value
	      if ( (*data_pos).second > max_list[(*data_pos).first] )
		{
                  max_list[(*data_pos).first] = (*data_pos).second;
		}
	    }
	}

#ifdef LIBREVERSE_DEBUG
      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DATA,
                           "----- Max List -----" );

      for ( boost::uint32_t index = 0;
            index < max_list.size();
            ++index )
	{
	  Trace::write_Trace ( TraceArea::IO,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "  #%1$d:   %2$s" )
					    % index
					    % max_list[index] ) );
	}
#endif /* LIBREVERSE_DEBUG */


      for ( typename classifier_types::Training_Set<Data_Type>::Data_List_t::iterator reset_pos = input_set.begin();
            reset_pos != input_set.end();
            ++reset_pos )
	{
	  typename classifier_types::Training_Data<Data_Type>::Variable_List_t::iterator data_pos = (*reset_pos)->begin();
	  ++data_pos;

	  for (;
               data_pos != (*reset_pos)->end();
               ++data_pos )
	    {
	      // If our denominator is not zero we divide
	      if ( max_list[(*data_pos).first] > 0 )
		{
		  double value = (*data_pos).second / max_list[(*data_pos).first];
               
		  if ( value > 1 )
		    {
		      std::cout << boost::format ("%1$8f / %2$8f > 1 (value = %3$8f)")
                        % (*data_pos).second
                        % max_list[(*data_pos).first]
                        % value << std::endl;

		      exit(1);
		    }

		  (*data_pos).second = value;
		}
	    }
	}

      Trace::write_Trace ( TraceArea::IO,
                           TraceLevel::DETAIL,
                           "Exiting IO::normalize" );
    }
  } /* namespace classifier */
} /* namespace libreverse */
