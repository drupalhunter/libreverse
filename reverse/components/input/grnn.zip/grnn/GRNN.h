/*  GRNN.h

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/

#ifndef GRNN_H
#define GRNN_H

#include "Training_Set.h"

namespace libreverse
{

  namespace classifier
  {
    template <typename Data_Type>
    class GRNN
    {
    public:

    
      GRNN ( double sigma,
	     typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t training,
	     typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t verificaion );

      /*! \brief Classify the training set
       * \return classification value representing the optimal sigma
       * \pre training_set is not empty
       * \pre verfication set is not empty
       */
      double execute ( void );

      /*! \brief Classify the training set
       * \return classification value representing the GRNN's answer
       * \pre training_set is not empty
       * \pre verfication set contains only one entry (target being classified)
       */
      double classify ( void );

      double get_Mean_Distance_Squared ( void ) const;

    private:

      /*!
       * \brief Compute the approximation function value from the verificaiton row
       * \param verification_row Row of verification data
       * \return approximation function value
       * \pre Verification row is not empty
       */
      double approximation_function
	( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_row );

      /*!
       * \brief Compute the hidden function value from the two input rows
       * \param verification_row Row of verification data
       * \param training_row Row of training data
       * \return hidden function value
       * \pre Stored sigma is not zero
       * \pre Verification row is not empty
       * \pre Training row is not empty
       */
      double hiddenFunction ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_row ,
			      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator training_row );

      /*!
       * \brief Compute the sum distance squared value from the two input rows
       * \param verification_row Row of verification data
       * \param training_row Row of training data
       * \return sum distance squared value
       * \pre Verification row is not empty
       * \pre Training row is not empty
       */
      double distance_squared ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_row ,
				typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator training_row );

      double m_sigma;

      double m_mean_distance_squared;

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t m_training;

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t m_verification;


    };
  
  } /* namespace classifier */
} /* namespace libreverse */

#include "GRNN.cpp"

#endif /* TRAINING_DATA_H */
