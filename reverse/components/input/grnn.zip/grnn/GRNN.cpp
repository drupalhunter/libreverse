


/*  GRNN.cpp

   Copyright (C) 2008 Stephen Torri

   This file is part of Libreverse.

   Libreverse is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published
   by the Free Software Foundation; either version 3, or (at your
   option) any later version.

   Libreverse is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.
*/
#include "GRNN.h"
#include <cmath>
#include <iostream>
#include <boost/format.hpp>
#include "libreverse/Trace.h"

namespace libreverse
{
  namespace classifier
  {

    template <typename Data_Type>
    GRNN<Data_Type>::GRNN ( double sigma,
			    typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t training,
			    typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t verification )
      : m_sigma ( sigma ),
	m_mean_distance_squared ( 0.0 ),
	m_training ( training ),
	m_verification ( verification )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN Constructor" );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Sigma: %1%" ) % m_sigma ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Size of training data: %1%" ) % m_training.size() ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Size of verification data: %1%" ) % m_verification.size() ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN Constructor" );
    }

    template <typename Data_Type>
    double
    GRNN<Data_Type>::execute ( void )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN::execute" );

      io::Preconditions::not_empty ( m_training );
      io::Preconditions::not_empty ( m_verification );

      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_pos = m_verification.begin();


      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Size of target set: %1%" ) % m_verification.size() ) );

      double success_rate = 0.0;
      double distance_squared_sum = 0.0;
      double result = 0.0;
      boost::uint32_t correct_classifications = 0;

      // FOR_EACH item, X, in verification set
      //   call approximation_function(X)
      for ( boost::uint32_t index = 0;
	    index < m_verification.size();
	    ++index )
        {
	  result = this->approximation_function ( verification_pos );

	  // GENERIC: Grab classifier target (e.g. Compiler ID for compiler classification)
	  typename classifier_types::Variable_Map::map_type::const_iterator comp_pos =
	    ( *verification_pos ).find ( Data_Type::CLASSIFIER_TARGET );

	  // GENERIC: classifier target
	  double classifier_target = ( *comp_pos ).second;

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "(target set index: %1%) Classifier target: %2%" )
					% index
					% classifier_target ) );

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "Result[%1%]: %2%" )
					    % index
					    % result ) );

	  // Calculate distance squared
	  distance_squared_sum += pow ( ( classifier_target - result ), 2.0 );

	  // Use classifier target
	  if ( fabs ( result - classifier_target ) < 0.5 )
            {
	      ++correct_classifications;
            }

	  ++verification_pos;
        }

      success_rate = ( static_cast<double> ( correct_classifications ) / static_cast<double> ( m_verification.size() ) );

      m_mean_distance_squared = distance_squared_sum / m_verification.size();
      
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Correct classifications: %1$d" ) % correct_classifications ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Total classifications: %1$d" ) % m_verification.size() ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Success rate: %1$1.10f" ) % success_rate ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Mean distance squared: %1$1.10f" ) % m_mean_distance_squared ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN::execute" );

      return success_rate;
    }

    template <typename Data_Type>
    double
    GRNN<Data_Type>::classify ( void )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN::classify" );

      io::Preconditions::not_empty ( m_training );
      io::Preconditions::equals ( m_verification.size(), static_cast<boost::uint32_t>(1) );
	
      typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_pos = m_verification.begin();

      double result = 0.0;

      result = this->approximation_function ( verification_pos );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Result: %1$d" ) % result ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN::classify" );

      return result;
    }

    // d = desired output is the first position in the training set
    //
    // \brief This function classifies one verification instance.
    template <typename Data_Type>
    double
    GRNN<Data_Type>::approximation_function ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator
					      verification_row )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN::approximation_function" );

      double weighted_sum_hfs = 0.0; // weighted sum of the results of the hiddenFunction based on desired output
      double sum_hfs = 0.0; // sum of the hiddenFunction results

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Size of training data: %1%" ) % m_training.size() ) );

      // For all rows in training set
      for ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator training_pos = m_training.begin();
	    training_pos != m_training.end();
	    ++training_pos )
        {
	  // X = row in verification data
	  // t[i] = training data
	  double hf = hiddenFunction ( verification_row, training_pos );

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "(%1%) Hidden function: %2%" )
					    % ( training_pos - m_training.begin() )
					    % hf ) );

	  // GENERIC: Grab classifier target (e.g. Compiler ID for compiler classification)
	  typename classifier_types::Variable_Map::map_type::const_iterator comp_pos =
	    ( *training_pos ).find ( Data_Type::CLASSIFIER_TARGET );

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "(%1%) Classifier target: %2%" )
					    % ( training_pos - m_training.begin() )
					    % ( *comp_pos ).second ) );

	  double classifier_target = ( *comp_pos ).second;

	  weighted_sum_hfs += hf * classifier_target;

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "(%1%) Weighted Sum Hidden function total: %2%" )
					    % ( training_pos - m_training.begin() )
					    % weighted_sum_hfs ) );

	  sum_hfs += hf;

	    Trace::write_Trace ( TraceArea::GRNN,
				 TraceLevel::DATA,
				 boost::str ( boost::format ( "(%1%) Sum Hidden function total: %2%" )
					      % ( training_pos - m_training.begin() )
					      % sum_hfs ) );
        }

      double result = 0.0;

      if ( sum_hfs != 0.0 )
        {
	  result = weighted_sum_hfs / sum_hfs;
        }

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Result: %1$1.10d" ) % result ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN::approximation_function" );

      return result;
    }

    template <typename Data_Type>
    double GRNN<Data_Type>::hiddenFunction ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator verification_row ,
					     typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator training_row )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN::hiddenFunction" );

      io::Preconditions::not_equal ( m_sigma, static_cast<double>(0.0) );

      double distance_squared_value = this->distance_squared ( verification_row, training_row );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Distanced squared: %1$f" ) % distance_squared_value ) );

      double denominator = 2 * pow ( m_sigma, 2.0 );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Sigma: %1$1.10f" ) % m_sigma ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Power: %1$1.10f" ) % ( pow ( m_sigma, 2.0 ) ) ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Denominator: %1$1.10f" ) % denominator ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Fraction: %1$1.10f" ) % ( ( -1 * ( distance_squared_value ) ) / denominator ) ) );

      double result = exp ( ( -1 * ( distance_squared_value ) ) / denominator );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DATA,
			   boost::str ( boost::format ( "Result: %1$1.10f" ) % result ) );

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN::hiddenFunction" );
      return result;
    }

    template <typename Data_Type>
    double GRNN<Data_Type>::distance_squared ( typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator
					       verification_row ,
					       typename classifier_types::Training_Set<Data_Type>::Candidate_Data_Map_t::const_iterator
					       training_row )
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Entering GRNN::distance_squared" );

      io::Preconditions::not_empty ( (*training_row) );
      io::Preconditions::not_empty ( (*verification_row) );

      double distance_squared_value = 0.0;

      classifier_types::Variable_Map::map_type training_map = *training_row;
      classifier_types::Variable_Map::map_type verification_map = *verification_row;

      // For all attributes in row
      for ( boost::uint32_t index = 1;
	    index < Data_Type::ATTRIBUTE_COUNT;
	    ++index )
	{
	  classifier_types::Variable_Map::map_type::const_iterator verification_pos = verification_map.find ( index );
	  classifier_types::Variable_Map::map_type::const_iterator training_pos = training_map.find ( index );

	  if ( verification_pos == verification_map.end() ||
	       training_pos == training_map.end() )
	    {
	      continue;
	    }

	  float verification_value = ( *verification_pos ).second;

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "%1$d: verification_value = %2$1.10f " )
					    % index
					    % verification_value ) );

	  float training_value = ( *training_pos ).second;

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "%1$d: training_value = %2$1.10f " )
					    % index
					    % training_value ) );

	  double next_distance_squared = pow ( ( verification_value - training_value ), 2.0 );

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "%1$d: next distance squared = %2$1.10f " )
					    % index
					    % next_distance_squared ) );

	  distance_squared_value += next_distance_squared;

	  Trace::write_Trace ( TraceArea::GRNN,
			       TraceLevel::DATA,
			       boost::str ( boost::format ( "Sum distance squared = %1$1.10f " )
					    % distance_squared_value ) );
        }

      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Exiting GRNN::distance_squared" );

      return distance_squared_value;
    }

    template <typename Data_Type>
    double
    GRNN<Data_Type>::get_Mean_Distance_Squared ( void ) const
    {
      Trace::write_Trace ( TraceArea::GRNN,
			   TraceLevel::DETAIL,
			   "Inside GRNN::get_Mean_Distance_Squared" );

      return m_mean_distance_squared;
    }

  } /* namespace classifier */
} /* namespace libreverse */
